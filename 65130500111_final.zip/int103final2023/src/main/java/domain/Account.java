//Pimpajee Seththirungplop 65130500111

package domain;

import java.io.Serializable;

public class Account implements Comparable<Account>, Serializable {
    private final String number;
    private final String ownerId;
    private double balance;
    
    public Account(String number, Customer owner) {
        /* (2.1) 
        throw InvalidAccountFormatException 
        if number is null or a blank string or owner is null */
        this.number = number;
        this.ownerId = owner.getId();
        this.balance = 0.0;

        try{
            if (number == null || number.isBlank() || owner == null){

            }
        }catch (InvalidAccountFormatException e){
            return ;
        }
    }
    @Override
    public String toString() {
        return String.format("Account(number:%s,ownerId:%s,balance:%f)",number,ownerId,balance);
    }
    public String getNumber() { return number; }
    public String getOwnerId() { return ownerId; }
    public double getBalance() { return balance; }
    public void deposit(double amount) { 
        /* (2.2) 
        throw InvalidAmountException if amount <= 0.0 */
//        if (amount <= 0.0) return false;
//        balance += amount;
//        return true;
//    }
        class InvalidAmountException{
            public static void main(String[] args) {
                try{
                    if (amount <= 0.0) ;
                }catch (Exception iae){

                }
            }
        }


        balance += amount;

    }
    public void withdraw(double amount) {
        /* (2.3) 
        throw InvalidAmountException if amount<=0.0 or amount > balance */
//        if (amount <= 0.0 || amount > balance) return false;
//      balance -= amount;
//      return true;
//   }

        try {
            if (amount <= 0.0 || amount > balance);
        }catch (InvalidAmountException iae){
            return null;
        }
            balance -= amount;
    }


    @Override
    public int compareTo(Account account) {
        return number.compareTo(account.number);
    }
}
