//Pimpajee Seththirungplop 65130500111

package domain;

import java.io.Serializable;

public class Customer implements Comparable<Customer>, Serializable {
    private final String id;
    private String name;
    
    public Customer(String id, String name) {
        /* (1.1) 
        throw InvalidCustomerFormatException 
        if id or name is null or a blank string */
        class InvalidCustomerFormatException{
            public static void main(String[] args) {
                try {
                    if (id == null || name == null || name.isBlank());
                }catch (Exception ex){
                    ex.getMessage();
                }
            }

        }
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return String.format("Customer(id:%s,name:%s)",id,name);
    }
    public String getId() { return id; }
    public String getName() { return name; }

    /* (1.2)
    throw InvalidCustomerFormatException 
    if name is null or a blank string */

    public void rename(String name) {
        try {
            if(name == null || name.isBlank());
        }catch (Exception e){
            System.out.println("Error");
            e.printStackTrace();
        }
        this.name = name;
    }
    
    @Override
    public int compareTo(Customer customer) {
        return id.compareTo(customer.id);
    }
}
