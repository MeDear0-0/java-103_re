//Pimpajee Seththirungplop 65130500111

package repository.file;

import domain.Customer;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Map;
import java.util.stream.Stream;
import repository.CustomerRepository;


public class FileCustomerRepository implements CustomerRepository {
    
    private String filename = "customers.dat";
    private long nextCustomerId;
    private Map<String,Customer> repo;

    public long FileCustomerRepository() {
        /* 8.1
        if the file exists, 
           open the file with buffer 
           (using FileInputStream, BufferedInputStream, ObjectInputStream)
           read nextCustomerId, and repo from the file
        else set nextCustomerId = 1 and set repo to a new TreeMap.

        8.2-8.5 are similar to InMemoryCustomerRepository 
        but when repo changes, always writes nextCustomerId and repo to the file
        (using FileOutputStream, BufferedOutputStream, ObjectOutputStream)
        */
//        File inputFile = new File(String.valueOf(new FileCustomerRepository()));
        if (filename != null) {
            try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println(line);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else {
            return nextCustomerId = 1 ;
        }
        return 0;
    }

    @Override
    public Customer create(String name) {
        var id = String.format("C%011d", nextCustomerId);
        if (repo.containsKey(id)) return null;
        var customer = new Customer(id,name);
        repo.put(id, customer);
        ++nextCustomerId;
        return customer;
    }

    @Override
    public boolean update(Customer customer) {
        if (customer == null) return false;
        repo.replace(customer.getId(), customer);
        return true;
    }

    @Override
    public Customer retrieve(String id) {
        if (id == null) return null;
        return repo.get(id);
    }

    @Override
    public Stream<Customer> stream() { return repo.values().stream(); }
    
}
