public class Room {
    int roomID;
    boolean isBooked;
}
