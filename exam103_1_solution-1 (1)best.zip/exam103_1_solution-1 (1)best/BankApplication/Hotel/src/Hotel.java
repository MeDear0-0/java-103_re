import java.util.List;

public class Hotel {
    public static void main(String[] args) {

        String hotelName = "Dear";
        int hotelID ;
        List[] rooms;
    }
}