package repository.file;

import domain.Customer;
import java.util.Map;
import java.util.stream.Stream;
import repository.CustomerRepository;

public class FileCustomerRepository implements CustomerRepository {
    
    private String filename = "customers.dat";
    private long nextCustomerId;
    private Map<String,Customer> repo;

    public FileCustomerRepository() { 
        /* 8.1
        if the file exists, 
           open the file with buffer 
           (using FileInputStream, BufferedInputStream, ObjectInputStream)
           read nextCustomerId, and repo from the file
        else set nextCustomerId = 1 and set repo to a new TreeMap.
        
        8.2-8.5 are similar to InMemoryCustomerRepository 
        but when repo changes, always writes nextCustomerId and repo to the file
        (using FileOutputStream, BufferedOutputStream, ObjectOutputStream)
        */
    }

    @Override
    public Customer retrieve(String id) {
        /* 8.2 */
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Customer create(String name) {
        /* 8.3 */
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean update(Customer customer) {
        /* 8.4 */
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Stream<Customer> stream() {
        /* 8.5 */
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
